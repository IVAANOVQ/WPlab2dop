package mk.ukim.finki.labb1.web.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;

import mk.ukim.finki.labb1.model.Artist;
import mk.ukim.finki.labb1.model.Song;
import mk.ukim.finki.labb1.service.ArtistService;
import mk.ukim.finki.labb1.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping(value = "/artists", method = RequestMethod.POST)
public class ArtistController {

    private final SongService songService;

    private final ArtistService artistService;

    public ArtistController(SongService songService, ArtistService artistService) {
        this.songService = songService;
        this.artistService = artistService;
    }

    @PostMapping
    public String artistsShowing(Model model, HttpServletRequest req) {
        String trackId = req.getParameter("trackId");
        Song song=songService.findByTrackId(trackId);
        List<Artist> artists = artistService.listArtists();
        Double novRating= Double.valueOf(req.getParameter("rating"));
        song.ratings.add(novRating);
        List<Artist> artistsForSong=new ArrayList<>();
        artistsForSong=song.getPerformers();
        model.addAttribute("trackId", trackId);
        model.addAttribute("artists", artists);
        model.addAttribute("song",song);
        model.addAttribute("songArtistsList",artistsForSong);
        Double avgRating=songService.averageRating(song);
        model.addAttribute("rating", avgRating);




        return "artistsList";
    }

    @GetMapping("/delete/{songId}/{artistId}")
    public String deleteArtist(@PathVariable Long songId,@PathVariable Long artistId) {
        Song song=songService.findById(songId);
        Artist artist=artistService.ArtistfindById(artistId);
        song.getPerformers().remove(artist);

        return "redirect:/songs";
    }




}



