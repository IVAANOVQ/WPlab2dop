package mk.ukim.finki.labb1.service;

import mk.ukim.finki.labb1.model.Artist;
import mk.ukim.finki.labb1.model.Song;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

public interface SongService {
    List<Song> listSongs();
    Artist addArtistToSong(Artist artist, Song song);
    public Song findByTrackId(String trackId);
    public Double averageRating(Song song);
    public  void deleteById(Long id);

    public void save(String title, String trackId,  String genre,  int releaseYear,Long albumId);

    Song findById(Long id);

}
