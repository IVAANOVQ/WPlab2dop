package mk.ukim.finki.labb1.service.Impl;

import mk.ukim.finki.labb1.model.Artist;
import mk.ukim.finki.labb1.model.Song;
import mk.ukim.finki.labb1.repository.SongRepository;
import mk.ukim.finki.labb1.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongServiceImpl implements SongService {
    public final SongRepository songRepository;

    public SongServiceImpl(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    @Override
    public List<Song> listSongs() {
      return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {
        return songRepository.addArtistToSong(artist,song);
    }

    @Override
    public Song findByTrackId(String trackId) {
       return songRepository.findByTrackId(trackId);
    }

    @Override
    public double averageRating(Song song) {
        return songRepository.averageRating(song);
    }

    @Override
    public void deleteById(Long id) {
        songRepository.deleteById(id);
    }

    @Override
    public void save(String title, String trackId, String genre, int releaseYear,Long albumId) {
        songRepository.save(title,trackId,genre,releaseYear,albumId);
    }

    @Override
    public Song findById(Long id) {
       return songRepository.findById(id);
    }


}
