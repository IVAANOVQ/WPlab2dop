package mk.ukim.finki.labb1.service.Impl;

import mk.ukim.finki.labb1.model.Album;
import mk.ukim.finki.labb1.repository.AlbumRepository;
import mk.ukim.finki.labb1.service.AlbumService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlbumServiceImpl implements AlbumService {
    public final AlbumRepository albumRepository;

    public AlbumServiceImpl(AlbumRepository albumRepository) {
        this.albumRepository = albumRepository;
    }

   public List<Album> findAll(){
      return albumRepository.findAll();

    }
    public Album findById(Long id) {
        return albumRepository.findById(id);
    }

}
