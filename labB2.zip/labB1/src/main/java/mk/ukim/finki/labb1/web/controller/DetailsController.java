package mk.ukim.finki.labb1.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.labb1.model.Artist;
import mk.ukim.finki.labb1.model.Song;
import mk.ukim.finki.labb1.service.ArtistService;
import mk.ukim.finki.labb1.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/songDetails",method = RequestMethod.POST)
public class DetailsController {
    private final SongService songService;
    private final ArtistService artistService;

    public DetailsController(SongService songService, ArtistService artistService) {
        this.songService = songService;
        this.artistService = artistService;
    }

    @PostMapping
    public String showDetails(Model model, HttpServletRequest request)
    {
        String trackId=request.getParameter("trackId");
        Song song= songService.findByTrackId(trackId);
        Long artistId=Long.valueOf(request.getParameter("artistId"));
        Artist artist=artistService.ArtistfindById(artistId);
        Double avgRating=songService.averageRating(song);

        List<Artist> artists=new ArrayList<>();
        artists=song.getPerformers();
        artists.add(artist);
        model.addAttribute("songTitle",song.getTitle());
        model.addAttribute("songGenre",song.getGenre());
        model.addAttribute("songYear",song.getReleaseYear());
        model.addAttribute("songArtistsList",artists);
        model.addAttribute("rating",songService.averageRating(song));

        return "songDetails";


    }
}
