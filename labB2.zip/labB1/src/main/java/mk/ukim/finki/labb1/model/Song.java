package mk.ukim.finki.labb1.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
@Data
@Entity
@NoArgsConstructor
public class Song {

    String trackId;
    String title;
    String genre;
    int releaseYear;
    @ManyToMany
    List<Artist> performers;
  @ElementCollection
    public List<Double> ratings;
  @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    Long id;
  @ManyToOne
  private Album album;

    public Song(String trackID, String title, String genre, int releaseYear, List<Artist> performers,Album album) {
        this.id = (long) (Math.random() * 1000);
        this.trackId = trackID;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.performers = performers;
        this.ratings=new ArrayList<>();
        this.album=album;
    }
    public Song( String title, String trackId,  String genre,  int releaseYear,Album album)
    {
        this.id = (long) (Math.random() * 1000);
        this.trackId = trackId;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.album=album;
    }

}
