package mk.ukim.finki.labb1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabB1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
